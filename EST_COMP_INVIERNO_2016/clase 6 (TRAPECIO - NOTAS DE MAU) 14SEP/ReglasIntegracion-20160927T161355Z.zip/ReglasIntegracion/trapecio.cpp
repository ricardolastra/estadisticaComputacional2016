#include <Rcpp.h>

// [[Rcpp::export]]
Rcpp::NumericVector trapecio(Rcpp::List limits_list, Rcpp::Function fun, double eps=1e-3) {
    // # el prerequisito es que fun sea un funcino R^d->R
    // # donde d es el tamaño de la lista, y la lista
    // # tiene los limites de integracion en cada dimension
    double trapecio = 0;
  
    int dim = limits_list.length();
    Rcpp::NumericVector limits = limits_list[0];
    double linf = limits[0];
    double lsup = limits[1];
    
    // std::cout << dim << "\n";
    
    if (dim==1) {
      // linf + i*eps) linf + (i+1)*eps) son los puntos en los que vamos a evaluar para
      // cada i mientras estemos entre linf y lsup
      for(int i=0; (linf + (i+1)*eps) < lsup; i++) {
        // std::cout << "iter" << i << "\n";
        // sumar area de trapecio: altura * (base1 + base2) / 2
        // por default Rcpp::Function regresa un vector, para hacerlo double tomamos el primero elemento
        Rcpp::NumericVector base1 = fun(linf + i*eps); 
        Rcpp::NumericVector base2 = fun(linf + (i+1)*eps);
        trapecio += eps*(base1[0] + base2[0])/2;
      }
    } else{
      
    }
    return trapecio;
   // else{
    //   f_i <- sapply(x_i, function(x) {
    //     trapecio(limits_list[-1], function(y) fun(c(x, y)), eps=eps)
    //   })
    // }
    // eps/2*sum(f_i[-length(f_i)] + f_i[-1])
    // return limits_list.size();
}


/*** R
res <- trapecio(
  limits_list = list(c(0,1)), 
  fun = function(x) x
)
res
*/
