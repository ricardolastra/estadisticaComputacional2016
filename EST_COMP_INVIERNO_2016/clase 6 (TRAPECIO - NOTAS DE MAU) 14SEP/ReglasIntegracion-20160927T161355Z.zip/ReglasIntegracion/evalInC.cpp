#include <Rcpp.h>
using namespace Rcpp; 
using namespace std; 

// [[Rcpp::export]]
NumericVector evalC(NumericVector value, string function_name) {
  Environment myEnv = Environment::global_env();
  Function fun = myEnv[function_name];
  return fun(value);
}

// [[Rcpp::export]]
int sampleC(NumericVector prob) {
  // RcppArmadillo ya tiene una version de sample
  prob = prob/Rcpp::sum(prob);
  int n_obj = prob.size();
  int u = std::rand();
  int i=0;
  while (prob[i] < u) {
    i++;
  }
  return i;
}

// You can include R code blocks in C++ files processed with sourceCpp
// (useful for testing and development). The R code will be automatically 
// run after the compilation.
//

/*** R
square <- function(x) x^2
evalInC(2, "square")
sample(c(.2, .5, .3))
*/
