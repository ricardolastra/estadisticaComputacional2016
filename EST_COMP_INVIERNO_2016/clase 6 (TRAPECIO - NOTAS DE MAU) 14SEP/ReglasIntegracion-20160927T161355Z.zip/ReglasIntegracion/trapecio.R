# VAMOS A PROGRAMAS LA REGLA DEL TRAPECIO
limits <- c(0, 1)
eps <- .01
fun <- function(x) {
  x^2
}

trapecio <- function(limits, fun, eps=1e-6) UseMethod("trapecio")
trapecio.numeric <- function(limits, fun, eps=1e-6){
  # limits es un vector de tamaño 2
  # eps es el tamaño de cada subintervalo
  x_i <- seq(
    from = limits[1],
    to = limits[2],
    by = eps
  )
  f_i <- sapply(x_i, fun)
  eps/2*sum(f_i[-length(x_i)] + f_i[-1])
}
limits_list <- list(c(0, 1), c(-1, 0))
fun <- function(x) return(1)


trapecio <- function(limits_list, fun, eps=1e-6){
  # el prerequisito es que fun sea un funcino R^d->R
  # donde d es el tamaño de la lista, y la lista
  # tiene los limites de integracion en cada dimension
  x_i <- seq(
    from = limits_list[[1]][1],
    to = limits_list[[1]][2],
    by = eps
  )
  if(length(limits_list)==1) {
    f_i <- sapply(x_i, fun)
  } else{
    f_i <- sapply(x_i, function(x) {
      trapecio(limits_list[-1], function(y) fun(c(x, y)), eps=eps)
    })
  }
  eps/2*sum(f_i[-length(f_i)] + f_i[-1])
}
trapecio(limits_list, function(x) sum(x^2), eps=1e-3) # VEN LA LENTITUD???? 




test <- function(x) UseMethod("test")
test.numeric <- function(x) "hola soy numerico"
test.character <- function(x) "hola soy character"
test.default <- function(x) "No se quien soy"
test.cool <- function(x) paste("hola soy coool y me llamo", x)
test("hola")
test(c(1,2,3,4))
test(mifactor)

x <- "Mauricio"
class(x)
attr(x, "class") <- "cool"
class(x)
test(x)

x <- hist(runif(1000))
class(x)
